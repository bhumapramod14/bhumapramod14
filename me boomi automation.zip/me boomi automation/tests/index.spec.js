import { test, chromium } from '@playwright/test';

test('Meebhoomi', async () => {
  const browser = await chromium.launch({
    channel: 'chrome',
    headless: false,
    args: [
      '--disable-blink-features=AutomationControlled',
      '--start-maximized'
    ]
  });

  const context = await browser.newContext({
    viewport: null
  });

  const page = await context.newPage();

  await page.goto('https://meebhoomi.ap.gov.in/', {
    waitUntil: 'networkidle'
  });

  await page.pause();
});