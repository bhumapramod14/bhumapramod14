import { test, expect } from '@playwright/test';

test('MeeBhoomi Login', async ({ page }) => {
  await page.goto('https://meebhoomi.ap.gov.in/');

  console.log('Please enter the mobile number manually.');

  await page.pause();

  await page.getByRole('button', { name: 'Get OTP' }).click();

  console.log('Please enter OTP and CAPTCHA manually.');

  await page.pause();

  await expect(page).toHaveURL(/meebhoomi/);
});